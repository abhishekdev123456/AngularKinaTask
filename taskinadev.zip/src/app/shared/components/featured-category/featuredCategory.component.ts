import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
@Component({
  selector: 'taskina-featured-category',
  templateUrl: './featuredCategory.component.html',
  styleUrls: ['./style.scss']
})
export class FeaturedCategoryComponent implements OnInit {

  constructor() { }
  
  ngOnInit() {
  }

}
