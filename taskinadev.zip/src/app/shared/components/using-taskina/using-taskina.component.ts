import { Component } from '@angular/core';

@Component({
  selector: 'taskina-using',
  templateUrl: './using-taskina.component.html',
  styleUrls: ['./using-taskina.component.scss']
})
export class UsingTaskinaComponent{

}
