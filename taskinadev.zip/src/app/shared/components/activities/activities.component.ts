import { Component } from '@angular/core';

@Component({
    selector: 'taskina-activities',
    templateUrl: './activities.component.html',
    styleUrls: ['./activities.component.scss']
})

export class ActivitiesComponent { 
    
}