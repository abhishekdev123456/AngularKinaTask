import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'taskina-join-taskina',
  templateUrl: './join-taskina.component.html',
  styleUrls: ['./join-taskina.component.scss']
})
export class JoinTaskinaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
