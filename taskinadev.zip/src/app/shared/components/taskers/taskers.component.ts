import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'taskina-taskers',
  templateUrl: './taskers.component.html',
  styleUrls: ['./taskers.component.scss']
})
export class TaskersComponent {
}
