import { Component } from '@angular/core';

@Component({
    selector: 'taskina-error',
    styleUrls: ['./style.scss'],
    templateUrl: './error-page.component.html'
})

export class ErrorPageComponent {

}