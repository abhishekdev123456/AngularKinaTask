import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'taskina-opportunities',
  templateUrl: './opportunities.component.html',
  styleUrls: ['./opportunities.component.scss']
})
export class OpportunitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
