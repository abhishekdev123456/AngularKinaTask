export class ConfirmationDialog{
    
}