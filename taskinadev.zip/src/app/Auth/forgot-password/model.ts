export class ForgotPasswordDialog{
    public email: string;
}