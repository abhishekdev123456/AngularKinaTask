import {Component,OnInit} from '@angular/core';
@Component({
    selector: 'app-badge',
    templateUrl: './badge.component.html'
})

export class BadgeComponent{
    constructor(){}

}