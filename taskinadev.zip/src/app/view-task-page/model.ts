export interface Message {
  words: string;
}
